<?php
require 'vendor/autoload.php'; // Include Composer's autoloader

use MongoDB\Client;

try {
    $client = new Client("mongodb://localhost:27017");
    $db = $client->my_database; // Replace with your database name
    $collection = $db->my_collection; // Replace with your collection name

    echo "Connected to MongoDB successfully!";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
